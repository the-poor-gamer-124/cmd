import discord
from discord.ext import commands

from core.paginator import EmbedPaginatorSession

class ServStatus(commands.Cog):
      def __init__(self, bot):
            self.bot = bot
      
      @commands.command(aliases=["help"])
      async def commands(self,ctx):
            """Shows bot commands"""
            embed = discord.Embed(title="Tags", description=f"{ctx.prefix}tag <name> - Use a tag!\n{ctx.prefix}tags add <name> <reply> - Create a tag!", color = 0xffffff)
            embed1 = discord.Embed(title="Fun", description=f"{ctx.prefix}choose <first object> <second object> Choose between two objects!\n{ctx.prefix}roll - Roll a dice\n{ctx.prefix}flip - Flip a coin\n{ctx.prefix}rps - Play Rock, Paper, Scissors!\n{ctx.prefix}8ball <question>? - The 8ball will reply to every question!\n{ctx.prefix}reverse <message> - !txet ruoy sesreveR\n{ctx.prefix}meme - Random Meme Generator\n{ctx.prefix}roast <person> - Insults the mentioned person!\n{ctx.prefix}smallcaps <messagge> - ᴄᴏɴᴠᴇʀᴛꜱ ʏᴏᴜʀ ᴛᴇxᴛ ɪɴ ꜱᴍᴀʟʟ ᴄᴀᴘꜱ!\n{ctx.prefix}cringe <text> - mAkE ThE TeXt cRiNgIeR!", color = 0xffffff)
            embed2 = discord.Embed(title="Hastebin", description=f"{ctx.prefix}hastebin <messagge> - Inserts your text on Hastebin", color = 0xffffff)
            embed3 = discord.Embed(title="Welcomer", description=f"{ctx.prefix}welcomer <channelid> <messagecontent> - Welcome every user that joins your server!", color = 0xffffff)
            embed4 = discord.Embed(title="Moderation", description=f"{ctx.prefix}purge <number> - Purge messages from 1 to 100\n{ctx.prefix}kick <person> - Kick a member of the server\n{ctx.prefix}mute <person> - Mute a person on the server\n{ctx.prefix}unmute <person> - Unmute a person on the server\n{ctx.prefix}nuke - Detonates every content of the chat on where you run this command!\n{ctx.prefix}ban <person> - Ban a person from the server\n{ctx.prefix}unban <person> - Remove the ban to a person of the server", color = 0xffffff)
            embed5 = discord.Embed(title="Announcements", description=f"{ctx.prefix}announcement start - Interactive announcement starter\n{ctx.prefix}announcement quick <channel> [role] <message> - An old way to create an announcement", color = 0xffffff)
            embed6 = discord.Embed(title="Other", description=f"{ctx.prefix}embed send <title> <description> - Send an embedded message\n{ctx.prefix}embed color <hexcode> - Change the color of your embedded message\n{ctx.prefix}welcomer <chat> <message> - Create a welcome message!\n{ctx.prefix}setdmmessage <message> - Send a welcome message in a DM\n{ctx.prefix}reactionrole add <message_id> <role> <emoji> - React to a message and you will get the role!\n{ctx.prefix}commands - Shows this message!\n{ctx.prefix}help - Shows this message!", color = 0xffffff)
            embeds = []
            embed_list = [embed, embed1, embed2, embed3, embed4, embed5, embed6]
            for embed in embed_list:
                embed.set_footer(text=f"Use the arrows to change page. • Prefix: {ctx.prefix}")
                embed.set_author(name="Webud.xyz", icon_url="https://i.imgur.com/nAdH0Ke.png")
                embeds.append(embed)
            session = EmbedPaginatorSession(ctx, *embeds)
            await session.run()
            
def setup(bot):
      bot.add_cog(ServStatus(bot))
